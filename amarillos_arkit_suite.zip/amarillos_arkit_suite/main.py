from __future__ import annotations

import math
from pathlib import Path

import bpy


ASSET_BLEND_NAME = "ARKit Controller Rig.blend"
DEFAULT_COLLECTION_NAME = "ARKit Controller Rig"
DEFAULT_RIG_NAME = "ARKit Controller Rig"
HEAD_FOLLOW_CONSTRAINT_NAME = "ARKit Suite Head Follow"

PARENT_EYE_BONE_NAME = "Eye Master"
LEFT_EYE_BONE_NAME = "Eye Guide L"
RIGHT_EYE_BONE_NAME = "Eye Guide R"
LEFT_BLINK_BONE_NAME = "Eye Blink L"
RIGHT_BLINK_BONE_NAME = "Eye Blink R"
LEFT_SQUINT_BONE_NAME = "Eye Squint L"
RIGHT_SQUINT_BONE_NAME = "Eye Squint R"

EYE_RANGE_X = 0.01
EYE_RANGE_Y = 0.01
PARENT_RANGE_X = 0.025
PARENT_RANGE_Y = 0.025
PARENT_RANGE_Z = 0.025
GUIDE_SCALE_Y_NEUTRAL = 1.0
GUIDE_SCALE_Y_WIDE = 1.125
GUIDE_SCALE_Y_CLOSED = 0.25
BLINK_BONE_RANGE_Y = 0.01
SQUINT_BONE_RANGE_Y = 0.01
CONVERGENCE_STRENGTH = 1

JAW_BONE_NAME = "Jaw"
JAW_OPEN_RANGE_X = 20
JAW_FORWARD_RANGE_X = -10
JAW_LEFT_RANGE_Z = -10
JAW_RIGHT_RANGE_Z = 10

MOUTH_CLOSE_BONE_NAME = "Mouth Close"
MOUTH_CLOSE_RANGE_Y = 0.01
MOUTH_TOP_LEFT_BONE_NAME = "Mouth Top L"
MOUTH_TOP_RIGHT_BONE_NAME = "Mouth Top R"
MOUTH_BOTTOM_LEFT_BONE_NAME = "Mouth Bot L"
MOUTH_BOTTOM_RIGHT_BONE_NAME = "Mouth Bot R"
MOUTH_SIDE_LEFT_BONE_NAME = "Mouth Side L"
MOUTH_SIDE_RIGHT_BONE_NAME = "Mouth Side R"
MOUTH_LIP_RANGE_Y = 0.01
MOUTH_LIP_RANGE_X = 0.01
MOUTH_SIDE_RANGE_Y = 0.01
MOUTH_DIMPLE_RANGE_X = 0.01

EYE_CONFIG = {
    "left": {
        "bone_name": LEFT_EYE_BONE_NAME,
        "vergence_sign": -1.0,
        "shape_keys": {
            "eyeLookUpLeft": ("y", 1.0),
            "eyeLookDownLeft": ("y", -1.0),
            "eyeLookInLeft": ("x", -1.0),
            "eyeLookOutLeft": ("x", 1.0),
        },
    },
    "right": {
        "bone_name": RIGHT_EYE_BONE_NAME,
        "vergence_sign": 1.0,
        "shape_keys": {
            "eyeLookUpRight": ("y", 1.0),
            "eyeLookDownRight": ("y", -1.0),
            "eyeLookInRight": ("x", 1.0),
            "eyeLookOutRight": ("x", -1.0),
        },
    },
}

EYELID_CONFIG = {
    "left": {
        "guide_bone_name": LEFT_EYE_BONE_NAME,
        "blink_bone_name": LEFT_BLINK_BONE_NAME,
        "squint_bone_name": LEFT_SQUINT_BONE_NAME,
        "shape_keys": {
            "eyeBlinkLeft": "blink",
            "eyeSquintLeft": "squint",
            "eyeWideLeft": "wide",
        },
    },
    "right": {
        "guide_bone_name": RIGHT_EYE_BONE_NAME,
        "blink_bone_name": RIGHT_BLINK_BONE_NAME,
        "squint_bone_name": RIGHT_SQUINT_BONE_NAME,
        "shape_keys": {
            "eyeBlinkRight": "blink",
            "eyeSquintRight": "squint",
            "eyeWideRight": "wide",
        },
    },
}

JAW_CONFIG = {
    "jawOpen": ("x", 1.0, "JAW_OPEN_RANGE_X"),
    "jawForward": ("x", -1.0, "JAW_FORWARD_RANGE_X"),
    "jawLeft": ("z", 1.0, "JAW_LEFT_RANGE_Z"),
    "jawRight": ("z", -1.0, "JAW_RIGHT_RANGE_Z"),
}

MOUTH_CONFIG = {
    "mouthClose": True,
}

MOUTH_LIP_CONFIG = {
    "mouthUpperUpLeft": MOUTH_TOP_LEFT_BONE_NAME,
    "mouthUpperUpRight": MOUTH_TOP_RIGHT_BONE_NAME,
    "mouthLowerDownLeft": MOUTH_BOTTOM_LEFT_BONE_NAME,
    "mouthLowerDownRight": MOUTH_BOTTOM_RIGHT_BONE_NAME,
}

MOUTH_SIDE_CONFIG = {
    "mouthPressLeft": (MOUTH_TOP_LEFT_BONE_NAME, 1.0),
    "mouthPressRight": (MOUTH_TOP_RIGHT_BONE_NAME, -1.0),
    "mouthStretchLeft": (MOUTH_BOTTOM_LEFT_BONE_NAME, -1.0),
    "mouthStretchRight": (MOUTH_BOTTOM_RIGHT_BONE_NAME, 1.0),
}

MOUTH_SIDE_FACE_CONFIG = {
    "mouthSmileLeft": (MOUTH_SIDE_LEFT_BONE_NAME, "y", 1.0),
    "mouthFrownLeft": (MOUTH_SIDE_LEFT_BONE_NAME, "y", -1.0),
    "mouthDimpleLeft": (MOUTH_SIDE_LEFT_BONE_NAME, "x", 1.0),
    "mouthSmileRight": (MOUTH_SIDE_RIGHT_BONE_NAME, "y", 1.0),
    "mouthFrownRight": (MOUTH_SIDE_RIGHT_BONE_NAME, "y", -1.0),
    "mouthDimpleRight": (MOUTH_SIDE_RIGHT_BONE_NAME, "x", -1.0),
}


def _all_arkit_shape_key_names() -> set[str]:
    names = set()
    for side_data in EYE_CONFIG.values():
        names.update(side_data["shape_keys"].keys())
    for side_data in EYELID_CONFIG.values():
        names.update(side_data["shape_keys"].keys())
    names.update(JAW_CONFIG.keys())
    names.update(MOUTH_CONFIG.keys())
    names.update(MOUTH_LIP_CONFIG.keys())
    names.update(MOUTH_SIDE_CONFIG.keys())
    names.update(MOUTH_SIDE_FACE_CONFIG.keys())
    return names


ARKIT_SHAPE_KEY_NAMES = _all_arkit_shape_key_names()


def _poll_mesh(_self, obj):
    return obj is None or obj.type == 'MESH'


def _poll_armature(_self, obj):
    return obj is None or obj.type == 'ARMATURE'


class AMARILLOS_ARKIT_SUITE_Settings(bpy.types.PropertyGroup):
    target_mesh: bpy.props.PointerProperty(
        name="Target Mesh",
        description="Mesh with ARKit shape keys",
        type=bpy.types.Object,
        poll=_poll_mesh,
    )

    controller_rig: bpy.props.PointerProperty(
        name="Controller Rig",
        description="ARKit controller rig armature",
        type=bpy.types.Object,
        poll=_poll_armature,
    )

    head_armature: bpy.props.PointerProperty(
        name="Head Armature",
        description="Character armature that owns the head bone",
        type=bpy.types.Object,
        poll=_poll_armature,
    )

    head_bone_name: bpy.props.StringProperty(
        name="Head Bone",
        description="Bone followed by the ARKit controller rig",
        default="head.x",
    )

    collection_name: bpy.props.StringProperty(
        name="Rig Collection",
        description="Collection to append from the packaged rig blend file",
        default=DEFAULT_COLLECTION_NAME,
    )

    rig_name: bpy.props.StringProperty(
        name="Rig Object",
        description="Expected controller rig armature object name",
        default=DEFAULT_RIG_NAME,
    )

    create_head_follow: bpy.props.BoolProperty(
        name="Follow Head",
        description="Add or refresh a Child Of constraint from the controller rig to the head bone",
        default=True,
    )


def _addon_settings(context) -> AMARILLOS_ARKIT_SUITE_Settings:
    return context.scene.amarillos_arkit_suite


def _asset_blend_path() -> Path:
    return Path(__file__).resolve().parent / "assets" / ASSET_BLEND_NAME


def _active_mesh(context):
    obj = context.active_object
    if obj is not None and obj.type == 'MESH':
        return obj
    return None


def _resolve_target_mesh(context):
    settings = _addon_settings(context)
    mesh_obj = settings.target_mesh or _active_mesh(context)
    if mesh_obj is None:
        raise ValueError("Choose a target mesh or select one in the viewport.")
    if mesh_obj.type != 'MESH':
        raise ValueError(f"'{mesh_obj.name}' is type '{mesh_obj.type}', expected MESH.")
    if mesh_obj.data.shape_keys is None:
        raise ValueError(f"Mesh '{mesh_obj.name}' has no shape keys.")
    return mesh_obj


def _resolve_existing_rig(settings):
    if settings.controller_rig is not None:
        return settings.controller_rig

    rig_obj = bpy.data.objects.get(settings.rig_name)
    if rig_obj is not None and rig_obj.type == 'ARMATURE':
        settings.controller_rig = rig_obj
        return rig_obj

    return None


def _iter_collection_objects(collection):
    for obj in collection.objects:
        yield obj
    for child in collection.children:
        yield from _iter_collection_objects(child)


def _find_armature_in_collection(collection, preferred_name):
    preferred = bpy.data.objects.get(preferred_name)
    if preferred is not None and preferred.type == 'ARMATURE':
        return preferred

    for obj in _iter_collection_objects(collection):
        if obj.type == 'ARMATURE':
            return obj

    return None


def append_controller_rig(settings):
    existing_rig = _resolve_existing_rig(settings)
    if existing_rig is not None:
        return existing_rig, False

    asset_path = _asset_blend_path()
    if not asset_path.is_file():
        raise FileNotFoundError(f"Missing packaged rig asset: {asset_path}")

    with bpy.data.libraries.load(str(asset_path), link=False) as (data_from, data_to):
        collection_name = settings.collection_name
        if collection_name not in data_from.collections:
            if not data_from.collections:
                raise ValueError(f"No collections found in '{asset_path.name}'.")
            collection_name = data_from.collections[0]
        data_to.collections = [collection_name]

    collection = data_to.collections[0]
    if collection.name not in bpy.context.scene.collection.children.keys():
        bpy.context.scene.collection.children.link(collection)

    rig_obj = _find_armature_in_collection(collection, settings.rig_name)
    if rig_obj is None:
        raise ValueError(f"No armature was found in appended collection '{collection.name}'.")

    settings.controller_rig = rig_obj
    settings.rig_name = rig_obj.name
    return rig_obj, True


def _infer_head_armature(mesh_obj):
    for modifier in mesh_obj.modifiers:
        if modifier.type == 'ARMATURE' and modifier.object is not None:
            return modifier.object
    return None


def _head_bone_exists(armature_obj, bone_name):
    return armature_obj is not None and bone_name in armature_obj.pose.bones


def _set_child_of_inverse(rig_obj, constraint):
    previous_active = bpy.context.view_layer.objects.active
    previous_selected = list(bpy.context.selected_objects)
    try:
        bpy.ops.object.select_all(action='DESELECT')
        rig_obj.select_set(True)
        bpy.context.view_layer.objects.active = rig_obj
        with bpy.context.temp_override(
            object=rig_obj,
            active_object=rig_obj,
            selected_editable_objects=[rig_obj],
        ):
            bpy.ops.constraint.childof_set_inverse(
                constraint=constraint.name,
                owner='OBJECT',
            )
    finally:
        bpy.ops.object.select_all(action='DESELECT')
        for obj in previous_selected:
            if obj.name in bpy.data.objects:
                obj.select_set(True)
        if previous_active is not None and previous_active.name in bpy.data.objects:
            bpy.context.view_layer.objects.active = previous_active


def ensure_head_follow_constraint(rig_obj, head_armature, head_bone_name):
    if rig_obj.type != 'ARMATURE':
        raise ValueError(f"'{rig_obj.name}' is type '{rig_obj.type}', expected ARMATURE.")
    if head_armature is None:
        raise ValueError("Choose a head armature or use a mesh with an Armature modifier.")
    if not _head_bone_exists(head_armature, head_bone_name):
        raise ValueError(f"Bone '{head_bone_name}' was not found on '{head_armature.name}'.")

    for constraint in list(rig_obj.constraints):
        if constraint.name == HEAD_FOLLOW_CONSTRAINT_NAME:
            rig_obj.constraints.remove(constraint)

    constraint = rig_obj.constraints.new(type='CHILD_OF')
    constraint.name = HEAD_FOLLOW_CONSTRAINT_NAME
    constraint.target = head_armature
    constraint.subtarget = head_bone_name
    constraint.owner_space = 'WORLD'
    constraint.target_space = 'WORLD'
    bpy.context.view_layer.update()
    _set_child_of_inverse(rig_obj, constraint)
    return constraint


def _get_shape_keys(mesh_obj):
    shape_keys = mesh_obj.data.shape_keys
    if shape_keys is None:
        raise ValueError(f"Mesh '{mesh_obj.name}' has no shape keys.")
    return shape_keys


def _clear_driver(key_block):
    try:
        key_block.driver_remove("value")
    except TypeError:
        pass


def _add_transform_var(driver, var_name, rig_obj, bone_name, transform_type):
    var = driver.variables.new()
    var.name = var_name
    var.type = 'TRANSFORMS'
    target = var.targets[0]
    target.id = rig_obj
    target.bone_target = bone_name
    target.transform_type = transform_type
    target.transform_space = 'LOCAL_SPACE'
    return var


def _add_object_transform_var(driver, var_name, obj, transform_type):
    var = driver.variables.new()
    var.name = var_name
    var.type = 'TRANSFORMS'
    target = var.targets[0]
    target.id = obj
    target.transform_type = transform_type
    target.transform_space = 'LOCAL_SPACE'
    return var


def _compose_x_expression(sign, vergence_sign):
    combined = (
        f"(cx / {EYE_RANGE_X}) + "
        f"(px / {PARENT_RANGE_X}) + "
        f"((-pz / {PARENT_RANGE_Z}) * {CONVERGENCE_STRENGTH} * {vergence_sign})"
    )
    if sign < 0:
        combined = f"-({combined})"
    return f"max(0, min(1, {combined}))"


def _compose_y_expression(sign):
    combined = f"(cy / {EYE_RANGE_Y}) + (py / {PARENT_RANGE_Y})"
    if sign < 0:
        combined = f"-({combined})"
    return f"max(0, min(1, {combined}))"


def _driver_expression(axis_name, sign, vergence_sign):
    if axis_name == "x":
        return _compose_x_expression(sign, vergence_sign)
    return _compose_y_expression(sign)


def _compose_wide_expression():
    return (
        f"max(0, min(1, "
        f"(gy - {GUIDE_SCALE_Y_NEUTRAL}) / "
        f"({GUIDE_SCALE_Y_WIDE} - {GUIDE_SCALE_Y_NEUTRAL})"
        f"))"
    )


def _compose_guide_closed_expression():
    return (
        f"max(0, min(1, "
        f"({GUIDE_SCALE_Y_NEUTRAL} - gy) / "
        f"({GUIDE_SCALE_Y_NEUTRAL} - {GUIDE_SCALE_Y_CLOSED})"
        f"))"
    )


def _compose_blink_bone_expression():
    return f"max(0, min(1, (-by / {BLINK_BONE_RANGE_Y})))"


def _compose_blink_bone_wide_expression():
    return f"max(0, min(1, (by / {BLINK_BONE_RANGE_Y})))"


def _compose_squint_bone_expression():
    return f"max(0, min(1, (qy / {SQUINT_BONE_RANGE_Y})))"


def _eyelid_expression(mode):
    if mode == "wide":
        return f"max({_compose_wide_expression()}, {_compose_blink_bone_wide_expression()})"
    if mode == "blink":
        return f"max({_compose_guide_closed_expression()}, {_compose_blink_bone_expression()})"
    if mode == "squint":
        return f"max({_compose_guide_closed_expression()}, {_compose_squint_bone_expression()})"
    raise ValueError(f"Unsupported eyelid mode '{mode}'.")


def _jaw_expression(axis_name, _sign, range_name):
    axis_var = "jx" if axis_name == "x" else "jz"
    range_value = globals()[range_name]
    range_radians = math.radians(abs(range_value))
    source = axis_var if range_value > 0 else f"-{axis_var}"
    return f"max(0, min(1, ({source} / {range_radians})))"


def _mouth_close_expression():
    jaw_open_radians = math.radians(abs(JAW_OPEN_RANGE_X))
    return (
        f"max(0, min(1, "
        f"(jx / {jaw_open_radians}) - "
        f"((-my) / {MOUTH_CLOSE_RANGE_Y})"
        f"))"
    )


def _mouth_lip_expression():
    return f"max(0, min(1, (ly / {MOUTH_LIP_RANGE_Y})))"


def _mouth_side_expression(sign):
    source = "lx" if sign > 0 else "-lx"
    return f"max(0, min(1, ({source} / {MOUTH_LIP_RANGE_X})))"


def _mouth_side_face_expression(axis_name, sign):
    if axis_name == "y":
        source = "sy" if sign > 0 else "-sy"
        return f"max(0, min(1, (({source} * rs) / {MOUTH_SIDE_RANGE_Y})))"

    source = "sx" if sign > 0 else "-sx"
    return f"max(0, min(1, (({source} * rs) / {MOUTH_DIMPLE_RANGE_X})))"


def _bind_one_shape_key(key_block, rig_obj, eye_bone_name, axis_name, sign, vergence_sign):
    _clear_driver(key_block)
    fcurve = key_block.driver_add("value")
    driver = fcurve.driver
    driver.type = 'SCRIPTED'
    _add_transform_var(driver, "cx", rig_obj, eye_bone_name, 'LOC_X')
    _add_transform_var(driver, "cy", rig_obj, eye_bone_name, 'LOC_Y')
    _add_transform_var(driver, "px", rig_obj, PARENT_EYE_BONE_NAME, 'LOC_X')
    _add_transform_var(driver, "py", rig_obj, PARENT_EYE_BONE_NAME, 'LOC_Y')
    _add_transform_var(driver, "pz", rig_obj, PARENT_EYE_BONE_NAME, 'LOC_Z')
    driver.expression = _driver_expression(axis_name, sign, vergence_sign)


def _bind_one_eyelid_shape_key(key_block, rig_obj, guide_bone_name, blink_bone_name, squint_bone_name, mode):
    _clear_driver(key_block)
    fcurve = key_block.driver_add("value")
    driver = fcurve.driver
    driver.type = 'SCRIPTED'
    _add_transform_var(driver, "gy", rig_obj, guide_bone_name, 'SCALE_Y')
    _add_transform_var(driver, "by", rig_obj, blink_bone_name, 'LOC_Y')
    _add_transform_var(driver, "qy", rig_obj, squint_bone_name, 'LOC_Y')
    driver.expression = _eyelid_expression(mode)


def _bind_one_jaw_shape_key(key_block, rig_obj, axis_name, sign, range_name):
    _clear_driver(key_block)
    fcurve = key_block.driver_add("value")
    driver = fcurve.driver
    driver.type = 'SCRIPTED'
    _add_transform_var(driver, "jx", rig_obj, JAW_BONE_NAME, 'ROT_X')
    _add_transform_var(driver, "jz", rig_obj, JAW_BONE_NAME, 'ROT_Z')
    driver.expression = _jaw_expression(axis_name, sign, range_name)


def _bind_mouth_close_shape_key(key_block, rig_obj):
    _clear_driver(key_block)
    fcurve = key_block.driver_add("value")
    driver = fcurve.driver
    driver.type = 'SCRIPTED'
    _add_transform_var(driver, "jx", rig_obj, JAW_BONE_NAME, 'ROT_X')
    _add_transform_var(driver, "my", rig_obj, MOUTH_CLOSE_BONE_NAME, 'LOC_Y')
    driver.expression = _mouth_close_expression()


def _bind_mouth_lip_shape_key(key_block, rig_obj, bone_name):
    _clear_driver(key_block)
    fcurve = key_block.driver_add("value")
    driver = fcurve.driver
    driver.type = 'SCRIPTED'
    _add_transform_var(driver, "ly", rig_obj, bone_name, 'LOC_Y')
    driver.expression = _mouth_lip_expression()


def _bind_mouth_side_shape_key(key_block, rig_obj, bone_name, sign):
    _clear_driver(key_block)
    fcurve = key_block.driver_add("value")
    driver = fcurve.driver
    driver.type = 'SCRIPTED'
    _add_transform_var(driver, "lx", rig_obj, bone_name, 'LOC_X')
    driver.expression = _mouth_side_expression(sign)


def _bind_mouth_side_face_shape_key(key_block, rig_obj, bone_name, axis_name, sign):
    _clear_driver(key_block)
    fcurve = key_block.driver_add("value")
    driver = fcurve.driver
    driver.type = 'SCRIPTED'
    _add_transform_var(driver, "sx", rig_obj, bone_name, 'LOC_X')
    _add_transform_var(driver, "sy", rig_obj, bone_name, 'LOC_Y')
    _add_object_transform_var(driver, "rs", rig_obj, 'SCALE_Y')
    driver.expression = _mouth_side_face_expression(axis_name, sign)


def _validate_required_bones(rig_obj):
    required_bones = [
        PARENT_EYE_BONE_NAME,
        JAW_BONE_NAME,
        MOUTH_CLOSE_BONE_NAME,
        MOUTH_TOP_LEFT_BONE_NAME,
        MOUTH_TOP_RIGHT_BONE_NAME,
        MOUTH_BOTTOM_LEFT_BONE_NAME,
        MOUTH_BOTTOM_RIGHT_BONE_NAME,
        MOUTH_SIDE_LEFT_BONE_NAME,
        MOUTH_SIDE_RIGHT_BONE_NAME,
    ]
    for side_data in EYE_CONFIG.values():
        required_bones.append(side_data["bone_name"])
    for side_data in EYELID_CONFIG.values():
        required_bones.append(side_data["guide_bone_name"])
        required_bones.append(side_data["blink_bone_name"])
        required_bones.append(side_data["squint_bone_name"])

    missing_bones = [bone_name for bone_name in required_bones if bone_name not in rig_obj.pose.bones]
    if missing_bones:
        joined = ", ".join(sorted(set(missing_bones)))
        raise ValueError(f"These pose bones were not found on '{rig_obj.name}': {joined}")


def bind_arkit_drivers(rig_obj, mesh_obj):
    if rig_obj is None or rig_obj.type != 'ARMATURE':
        raise ValueError("Choose an ARKit controller armature.")

    shape_keys = _get_shape_keys(mesh_obj)
    _validate_required_bones(rig_obj)
    created_count = 0

    for side_data in EYE_CONFIG.values():
        eye_bone_name = side_data["bone_name"]
        vergence_sign = side_data["vergence_sign"]
        for shape_key_name, (axis_name, sign) in side_data["shape_keys"].items():
            key_block = shape_keys.key_blocks.get(shape_key_name)
            if key_block is None:
                continue
            _bind_one_shape_key(key_block, rig_obj, eye_bone_name, axis_name, sign, vergence_sign)
            created_count += 1

    for side_data in EYELID_CONFIG.values():
        for shape_key_name, mode in side_data["shape_keys"].items():
            key_block = shape_keys.key_blocks.get(shape_key_name)
            if key_block is None:
                continue
            _bind_one_eyelid_shape_key(
                key_block,
                rig_obj,
                side_data["guide_bone_name"],
                side_data["blink_bone_name"],
                side_data["squint_bone_name"],
                mode,
            )
            created_count += 1

    for shape_key_name, (axis_name, sign, range_name) in JAW_CONFIG.items():
        key_block = shape_keys.key_blocks.get(shape_key_name)
        if key_block is None:
            continue
        _bind_one_jaw_shape_key(key_block, rig_obj, axis_name, sign, range_name)
        created_count += 1

    for shape_key_name in MOUTH_CONFIG.keys():
        key_block = shape_keys.key_blocks.get(shape_key_name)
        if key_block is None:
            continue
        _bind_mouth_close_shape_key(key_block, rig_obj)
        created_count += 1

    for shape_key_name, bone_name in MOUTH_LIP_CONFIG.items():
        key_block = shape_keys.key_blocks.get(shape_key_name)
        if key_block is None:
            continue
        _bind_mouth_lip_shape_key(key_block, rig_obj, bone_name)
        created_count += 1

    for shape_key_name, (bone_name, sign) in MOUTH_SIDE_CONFIG.items():
        key_block = shape_keys.key_blocks.get(shape_key_name)
        if key_block is None:
            continue
        _bind_mouth_side_shape_key(key_block, rig_obj, bone_name, sign)
        created_count += 1

    for shape_key_name, (bone_name, axis_name, sign) in MOUTH_SIDE_FACE_CONFIG.items():
        key_block = shape_keys.key_blocks.get(shape_key_name)
        if key_block is None:
            continue
        _bind_mouth_side_face_shape_key(key_block, rig_obj, bone_name, axis_name, sign)
        created_count += 1

    mesh_obj["amarillos_arkit_suite_controller"] = rig_obj.name
    return created_count


def _shape_key_name_from_driver_path(data_path):
    prefix = 'key_blocks["'
    suffix = '"].value'
    if data_path.startswith(prefix) and data_path.endswith(suffix):
        return data_path[len(prefix):-len(suffix)]
    return None


def _iter_managed_driver_fcurves(mesh_obj):
    shape_keys = _get_shape_keys(mesh_obj)
    animation_data = shape_keys.animation_data
    if animation_data is None or animation_data.drivers is None:
        return

    for fcurve in list(animation_data.drivers):
        key_name = _shape_key_name_from_driver_path(fcurve.data_path)
        if key_name in ARKIT_SHAPE_KEY_NAMES:
            yield fcurve


def set_managed_drivers_enabled(mesh_obj, enabled):
    count = 0
    for fcurve in _iter_managed_driver_fcurves(mesh_obj):
        fcurve.mute = not enabled
        count += 1
    return count


def remove_managed_drivers(mesh_obj):
    shape_keys = _get_shape_keys(mesh_obj)
    count = 0
    for key_name in ARKIT_SHAPE_KEY_NAMES:
        key_block = shape_keys.key_blocks.get(key_name)
        if key_block is None:
            continue
        before = len(list(_iter_managed_driver_fcurves(mesh_obj)))
        _clear_driver(key_block)
        after = len(list(_iter_managed_driver_fcurves(mesh_obj)))
        if after < before:
            count += 1
    return count


class AMARILLOS_ARKIT_SUITE_OT_append_controller(bpy.types.Operator):
    bl_idname = "amarillos_arkit_suite.append_controller"
    bl_label = "Append Controller Rig"
    bl_description = "Append the packaged ARKit controller rig collection"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = _addon_settings(context)
        try:
            rig_obj, appended = append_controller_rig(settings)
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

        action = "Appended" if appended else "Found existing"
        self.report({'INFO'}, f"{action} controller rig '{rig_obj.name}'.")
        return {'FINISHED'}


class AMARILLOS_ARKIT_SUITE_OT_bind(bpy.types.Operator):
    bl_idname = "amarillos_arkit_suite.bind"
    bl_label = "Bind / Refresh Drivers"
    bl_description = "Append or use the controller rig, then bind ARKit shape key drivers"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = _addon_settings(context)
        try:
            mesh_obj = _resolve_target_mesh(context)
            settings.target_mesh = mesh_obj
            rig_obj = _resolve_existing_rig(settings)
            if rig_obj is None:
                rig_obj, _appended = append_controller_rig(settings)

            driver_count = bind_arkit_drivers(rig_obj, mesh_obj)

            if settings.create_head_follow:
                head_armature = settings.head_armature or _infer_head_armature(mesh_obj)
                if head_armature is not None:
                    settings.head_armature = head_armature
                    ensure_head_follow_constraint(rig_obj, head_armature, settings.head_bone_name)
                else:
                    self.report({'WARNING'}, "Drivers bound, but no head armature was found for the Child Of constraint.")

        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

        self.report({'INFO'}, f"Bound {driver_count} ARKit drivers on '{mesh_obj.name}'.")
        return {'FINISHED'}


class AMARILLOS_ARKIT_SUITE_OT_set_drivers_enabled(bpy.types.Operator):
    bl_idname = "amarillos_arkit_suite.set_drivers_enabled"
    bl_label = "Set ARKit Drivers Enabled"
    bl_description = "Mute or unmute the ARKit shape key drivers managed by this add-on"
    bl_options = {'REGISTER', 'UNDO'}

    enabled: bpy.props.BoolProperty(default=True)

    def execute(self, context):
        try:
            mesh_obj = _resolve_target_mesh(context)
            count = set_managed_drivers_enabled(mesh_obj, self.enabled)
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

        state = "Enabled" if self.enabled else "Disabled"
        self.report({'INFO'}, f"{state} {count} ARKit drivers on '{mesh_obj.name}'.")
        return {'FINISHED'}


class AMARILLOS_ARKIT_SUITE_OT_remove_drivers(bpy.types.Operator):
    bl_idname = "amarillos_arkit_suite.remove_drivers"
    bl_label = "Remove ARKit Drivers"
    bl_description = "Remove the ARKit shape key drivers managed by this add-on"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            mesh_obj = _resolve_target_mesh(context)
            count = remove_managed_drivers(mesh_obj)
        except Exception as exc:
            self.report({'ERROR'}, str(exc))
            return {'CANCELLED'}

        self.report({'INFO'}, f"Removed {count} ARKit drivers from '{mesh_obj.name}'.")
        return {'FINISHED'}


def draw_ui(layout, context):
    settings = _addon_settings(context)
    mesh_obj = settings.target_mesh or _active_mesh(context)

    col = layout.column(align=True)
    col.prop(settings, "target_mesh")
    if settings.target_mesh is None and mesh_obj is not None:
        col.label(text=f"Using active mesh: {mesh_obj.name}", icon='MESH_DATA')

    rig_box = layout.box()
    rig_box.label(text="Controller", icon='ARMATURE_DATA')
    rig_col = rig_box.column(align=True)
    rig_col.prop(settings, "controller_rig")
    rig_col.prop(settings, "collection_name")
    rig_col.prop(settings, "rig_name")
    rig_col.operator("amarillos_arkit_suite.append_controller", icon='APPEND_BLEND')

    follow_box = layout.box()
    follow_box.prop(settings, "create_head_follow")
    follow_col = follow_box.column(align=True)
    follow_col.enabled = settings.create_head_follow
    follow_col.prop(settings, "head_armature")
    follow_col.prop(settings, "head_bone_name")

    layout.operator("amarillos_arkit_suite.bind", icon='CONSTRAINT_BONE')

    row = layout.row(align=True)
    op = row.operator("amarillos_arkit_suite.set_drivers_enabled", text="Disable Drivers", icon='HIDE_ON')
    op.enabled = False
    op = row.operator("amarillos_arkit_suite.set_drivers_enabled", text="Enable Drivers", icon='HIDE_OFF')
    op.enabled = True

    layout.operator("amarillos_arkit_suite.remove_drivers", icon='TRASH')


classes = (
    AMARILLOS_ARKIT_SUITE_Settings,
    AMARILLOS_ARKIT_SUITE_OT_append_controller,
    AMARILLOS_ARKIT_SUITE_OT_bind,
    AMARILLOS_ARKIT_SUITE_OT_set_drivers_enabled,
    AMARILLOS_ARKIT_SUITE_OT_remove_drivers,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.amarillos_arkit_suite = bpy.props.PointerProperty(
        type=AMARILLOS_ARKIT_SUITE_Settings,
    )


def unregister():
    if hasattr(bpy.types.Scene, "amarillos_arkit_suite"):
        del bpy.types.Scene.amarillos_arkit_suite

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
