bl_info = {
    "name": "Amarillo's ARKit Suite",
    "author": "Amarillo",
    "version": (0, 1, 0),
    "blender": (4, 1, 0),
    "location": "View3D > Sidebar > Amarillo",
    "description": "Append an ARKit controller rig and bind it to ARKit shape keys",
    "warning": "",
    "doc_url": "",
    "category": "Animation",
}


import importlib
import traceback

import bpy


_needs_reload = "bpy" in locals()
_main = locals().get("_main")
_last_import_error = ""


def _load_main_module() -> None:
    global _main, _last_import_error

    _last_import_error = ""
    try:
        if _needs_reload and _main is not None:
            _main = importlib.reload(_main)
        else:
            from . import main as imported_main

            _main = imported_main
    except Exception as exc:
        _main = None
        _last_import_error = f"Import failed: {exc}"
        print("[Amarillo's ARKit Suite] Failed to import/reload main module")
        print(traceback.format_exc())


_load_main_module()


class AMARILLOS_ARKIT_SUITE_PT_panel(bpy.types.Panel):
    bl_label = "Amarillo's ARKit Suite"
    bl_idname = "AMARILLOS_ARKIT_SUITE_PT_panel"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Amarillo"

    def draw(self, context):
        layout = self.layout

        if _main is None:
            box = layout.box()
            box.label(text="ARKit Suite failed to load.", icon="ERROR")
            if _last_import_error:
                box.label(text=_last_import_error[:120], icon="INFO")
            box.label(text="Disable and enable the add-on again.", icon="INFO")
            return

        _main.draw_ui(layout, context)


classes = (
    AMARILLOS_ARKIT_SUITE_PT_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    if _main is None:
        _load_main_module()
    if _main is not None:
        _main.register()


def unregister():
    if _main is not None:
        _main.unregister()

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
